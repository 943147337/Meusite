function Contact() {
    try {
        return (
            <section id="contato" className="py-16 bg-white" data-name="contact">
                <div className="container mx-auto px-4">
                    <h2 className="section-title" data-name="contact-title">Entre em Contato</h2>
                    <p className="section-subtitle" data-name="contact-subtitle">
                        Vamos tornar seu evento especial juntos
                    </p>
                    <div className="max-w-3xl mx-auto" data-name="contact-content">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            <div className="bg-pink-50 p-6 rounded-lg" data-name="contact-info">
                                <h3 className="text-xl font-bold mb-4">Informações de Contato</h3>
                                <div className="space-y-4">
                                    <p className="flex items-center">
                                        <i className="fas fa-phone text-pink-500 mr-3"></i>
                                        (11) 99999-9999
                                    </p>
                                    <p className="flex items-center">
                                        <i className="fas fa-envelope text-pink-500 mr-3"></i>
                                        contato@soniaventos.com
                                    </p>
                                    <p className="flex items-center">
                                        <i className="fas fa-map-marker-alt text-pink-500 mr-3"></i>
                                        São Paulo, SP
                                    </p>
                                    <div className="flex space-x-4 mt-6">
                                        <a href="#" className="text-pink-500 hover:text-pink-600">
                                            <i className="fab fa-instagram text-2xl"></i>
                                        </a>
                                        <a href="#" className="text-pink-500 hover:text-pink-600">
                                            <i className="fab fa-facebook text-2xl"></i>
                                        </a>
                                        <a href="#" className="text-pink-500 hover:text-pink-600">
                                            <i className="fab fa-whatsapp text-2xl"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <form className="space-y-4" data-name="contact-form">
                                <div>
                                    <input type="text" 
                                           placeholder="Seu Nome" 
                                           className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-pink-500" />
                                </div>
                                <div>
                                    <input type="email" 
                                           placeholder="Seu Email" 
                                           className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-pink-500" />
                                </div>
                                <div>
                                    <textarea placeholder="Sua Mensagem" 
                                              rows="4" 
                                              className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:border-pink-500"></textarea>
                                </div>
                                <button type="submit" 
                                        className="w-full bg-pink-500 text-white py-3 rounded-lg hover:bg-pink-600 transition duration-300">
                                    Enviar Mensagem
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </section>
        );
    } catch (error) {
        console.error('Contact component error:', error);
        reportError(error);
        return null;
    }
}
