function Hero() {
    try {
        return (
            <section id="inicio" className="pt-20 pb-12 bg-gradient-to-r from-pink-50 to-purple-50" data-name="hero">
                <div className="container mx-auto px-4 flex flex-col md:flex-row items-center">
                    <div className="md:w-1/2 mb-8 md:mb-0" data-name="hero-content">
                        <h1 className="text-4xl md:text-5xl font-bold mb-4 text-gray-800" data-name="hero-title">
                            Transformando Sonhos em Realidade
                        </h1>
                        <p className="text-lg text-gray-600 mb-8" data-name="hero-description">
                            Especialistas em decoração para casamentos, aniversários e eventos especiais.
                            Criamos momentos únicos e inesquecíveis para você.
                        </p>
                        <a href="#contato" 
                           className="bg-pink-500 text-white px-8 py-3 rounded-full hover:bg-pink-600 transition duration-300"
                           data-name="hero-cta">
                            Solicitar Orçamento
                        </a>
                    </div>
                    <div className="md:w-1/2" data-name="hero-image">
                        <img src="https://images.unsplash.com/photo-1519167758481-83f550bb49b3?q=80&w=600"
                             alt="Decoração de Eventos"
                             className="rounded-lg shadow-xl"
                             data-name="hero-img" />
                    </div>
                </div>
            </section>
        );
    } catch (error) {
        console.error('Hero component error:', error);
        reportError(error);
        return null;
    }
}
