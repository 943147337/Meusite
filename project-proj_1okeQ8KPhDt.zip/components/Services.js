function Services() {
    try {
        const services = [
            {
                icon: "fa-ring",
                title: "Casamentos",
                description: "Decorações elegantes e românticas para o seu dia especial"
            },
            {
                icon: "fa-cake-candles",
                title: "Aniversários",
                description: "Temas personalizados para todas as idades"
            },
            {
                icon: "fa-champagne-glasses",
                title: "Eventos Corporativos",
                description: "Ambientação profissional para seus eventos empresariais"
            }
        ];

        return (
            <section id="servicos" className="py-16 bg-white" data-name="services">
                <div className="container mx-auto px-4">
                    <h2 className="section-title" data-name="services-title">Nossos Serviços</h2>
                    <p className="section-subtitle" data-name="services-subtitle">
                        Oferecemos uma variedade de serviços para tornar seu evento único
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8" data-name="services-grid">
                        {services.map((service, index) => (
                            <div key={index} 
                                 className="p-6 bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow duration-300"
                                 data-name={`service-card-${index}`}>
                                <i className={`fas ${service.icon} text-4xl text-pink-500 mb-4`}></i>
                                <h3 className="text-xl font-bold mb-3">{service.title}</h3>
                                <p className="text-gray-600">{service.description}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>
        );
    } catch (error) {
        console.error('Services component error:', error);
        reportError(error);
        return null;
    }
}
