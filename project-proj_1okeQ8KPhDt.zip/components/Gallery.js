function Gallery() {
    try {
        const images = [
            {
                url: "https://images.unsplash.com/photo-1519225421980-715cb0215aed?w=500",
                title: "Casamento Elegante"
            },
            {
                url: "https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?w=500",
                title: "Festa de 15 Anos"
            },
            {
                url: "https://images.unsplash.com/photo-1478146896981-b80fe463b330?w=500",
                title: "Decoração Romântica"
            },
            {
                url: "https://images.unsplash.com/photo-1470162656305-6f429ba817bf?w=500",
                title: "Evento Corporativo"
            }
        ];

        return (
            <section id="galeria" className="py-16 bg-gray-50" data-name="gallery">
                <div className="container mx-auto px-4">
                    <h2 className="section-title" data-name="gallery-title">Nossa Galeria</h2>
                    <p className="section-subtitle" data-name="gallery-subtitle">
                        Confira alguns dos nossos trabalhos mais recentes
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6" data-name="gallery-grid">
                        {images.map((image, index) => (
                            <div key={index} 
                                 className="relative overflow-hidden rounded-lg group"
                                 data-name={`gallery-item-${index}`}>
                                <img src={image.url} 
                                     alt={image.title}
                                     className="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-110" />
                                <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                                    <h3 className="text-white text-xl font-semibold">{image.title}</h3>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </section>
        );
    } catch (error) {
        console.error('Gallery component error:', error);
        reportError(error);
        return null;
    }
}
