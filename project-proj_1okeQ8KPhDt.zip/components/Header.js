function Header() {
    try {
        return (
            <header className="header fixed w-full top-0 z-50" data-name="header">
                <div className="container mx-auto px-4 py-4 flex justify-between items-center">
                    <a href="#" className="logo flex items-center" data-name="logo">
                        <i className="fas fa-heart text-pink-500 mr-2"></i>
                        <span className="font-bold text-xl">Sônia Eventos</span>
                    </a>
                    <nav className="hidden md:flex space-x-6" data-name="navigation">
                        <a href="#inicio" className="nav-link" data-name="nav-home">Início</a>
                        <a href="#servicos" className="nav-link" data-name="nav-services">Serviços</a>
                        <a href="#galeria" className="nav-link" data-name="nav-gallery">Galeria</a>
                        <a href="#contato" className="nav-link" data-name="nav-contact">Contato</a>
                    </nav>
                </div>
            </header>
        );
    } catch (error) {
        console.error('Header component error:', error);
        reportError(error);
        return null;
    }
}
