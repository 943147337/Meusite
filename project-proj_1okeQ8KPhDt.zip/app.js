function App() {
    try {
        return (
            <div className="app" data-name="app">
                <Header />
                <main>
                    <Hero />
                    <Services />
                    <Gallery />
                    <Contact />
                </main>
                <footer className="bg-gray-900 text-white py-6 text-center" data-name="footer">
                    <p>© 2024 Sônia Eventos. Todos os direitos reservados.</p>
                </footer>
            </div>
        );
    } catch (error) {
        console.error('App component error:', error);
        reportError(error);
        return null;
    }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
